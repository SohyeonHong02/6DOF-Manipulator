#include <ros/ros.h>
#include <geometry_msgs/Point.h>
#include <QApplication>
#include <QMainWindow>
#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QColor>
#include <QBrush>
#include <QPen>
#include <QPointF>


using namespace std;


class CircleWidget : public QWidget
{
public:
    CircleWidget(QWidget *parent = nullptr)
        : QWidget(parent),
          bx(0),
          by(0),
          rfx(10),
          rfy(10),
          lfx(10),
          lfy(10)
    {
        QVBoxLayout *layout = new QVBoxLayout(this);
        circle_label = new QLabel(this);
        layout->addWidget(circle_label);

        rf_label = new QLabel(this);
        layout->addWidget(rf_label);

        lf_label = new QLabel(this);
        layout->addWidget(lf_label);
    }

    void setPositions(double bx, double by, double rfx, double rfy, double lfx, double lfy)
    {
        this->bx = bx;
        this->by = by;
        this->rfx = rfx;
        this->rfy = rfy;
        this->lfx = lfx;
        this->lfy = lfy;

        circle_label->setText(QString("Circle: (%1, %2)").arg(bx, 0, 'f', 3).arg(by, 0, 'f', 3));
        circle_label->move(10, 10);

        rf_label->setText(QString("RF: (%1, %2)").arg(rfx, 0, 'f', 3).arg(rfy, 0, 'f', 3));
        rf_label->move(700, 120);

        lf_label->setText(QString("LF: (%1, %2)").arg(lfx, 0, 'f', 3).arg(lfy, 0, 'f', 3));
        lf_label->move(700, 140);

        update();
    }

protected:
    void paintEvent(QPaintEvent *event) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        painter.setPen(Qt::NoPen);
        painter.setBrush(QBrush(QColor(255, 0, 0)));
        qreal radius = 50;
        painter.drawEllipse(QPointF(bx, by), radius, radius);

        painter.setPen(QPen(Qt::white, 8));
        painter.setBrush(QBrush(QColor(255, 255, 255)));
        painter.drawPoint(QPointF(rfx, rfy));
        painter.drawPoint(QPointF(lfx, lfy));

        painter.setPen(Qt::NoPen);
        painter.setBrush(QBrush(QColor(0, 0, 0)));
        qreal rect_width = 170;
        qreal rect_height = 280;
        painter.drawRect(QRectF(rfx - 65, rfy - 155, rect_width, rect_height));
        painter.setBrush(QBrush(QColor(0, 0, 255)));
        painter.drawRect(QRectF(lfx - 105, lfy - 155, rect_width, rect_height));
    }

private:
    double bx;
    double by;
    double rfx;
    double rfy;
    double lfx;
    double lfy;
    QLabel *circle_label;
    QLabel *rf_label;
    QLabel *lf_label;
};

class MainWindow : public QMainWindow
{
public:
    MainWindow()
        : x(10),
          y(10),
          x2(10),
          y2(10),
          x3(10),
          y3(10)
    {
        setGeometry(0, 0, 1000, 1000);

        QVBoxLayout *layout = new QVBoxLayout();
        QWidget *central_widget = new QWidget();
        central_widget->setLayout(layout);

        circle_widget = new CircleWidget();
        layout->addWidget(circle_widget);

        setCentralWidget(central_widget);

        circle_position_sub = nh.subscribe("circle_position", 10, &MainWindow::circlePositionCallback, this);
        foot_position_sub = nh.subscribe("foot_position", 10, &MainWindow::footPositionCallback, this);
        foot3_position_sub = nh.subscribe("foot3_position", 10, &MainWindow::foot3PositionCallback, this);
    }

    void circlePositionCallback(const geometry_msgs::Point::ConstPtr &msg)
    {
        x = msg->x;
        y = msg->y;
        updateCircleWidget();
    }

    void footPositionCallback(const geometry_msgs::Point::ConstPtr &msg)
    {
        x2 = msg->x;
        y2 = msg->y;
        updateCircleWidget();
    }

    void foot3PositionCallback(const geometry_msgs::Point::ConstPtr &msg)
    {
        x3 = msg->x;
        y3 = msg->y;
        updateCircleWidget();
    }

private:
    void updateCircleWidget()
    {
        circle_widget->setPositions(x, y, x2, y2, x3, y3);
    }

    ros::NodeHandle nh;
    ros::Subscriber circle_position_sub;
    ros::Subscriber foot_position_sub;
    ros::Subscriber foot3_position_sub;
    double x;
    double y;
    double x2;
    double y2;
    double x3;
    double y3;
    CircleWidget *circle_widget;
};
// ...

int main(int argc, char **argv)
{
    ros::init(argc, argv, "circle_gui_node");

    QApplication app(argc, argv);
    MainWindow main_window;
    main_window.show();

    ros::AsyncSpinner spinner(1);  // Use 1 thread
    spinner.start();

    return app.exec();
}
