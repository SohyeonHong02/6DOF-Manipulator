#include <ros/ros.h>
#include <geometry_msgs/Point.h>
#include <random>

int main(int argc, char** argv)
{
    ros::init(argc, argv, "circle_position_publisher");
    ros::NodeHandle nh;
    ros::Publisher publisher = nh.advertise<geometry_msgs::Point>("circle_position", 10);
    ros::Publisher publisher2 = nh.advertise<geometry_msgs::Point>("foot_position", 10);
    ros::Publisher publisher3 = nh.advertise<geometry_msgs::Point>("foot3_position", 10);
    ros::Rate rate(0.5);

    while (ros::ok())
    {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<double> uniform_dist(100.0, 900.0);

        double x = uniform_dist(gen);
        double y = uniform_dist(gen);
        geometry_msgs::Point msg;
        msg.x = x;
        msg.y = y;

        std::uniform_real_distribution<double> uniform_dist2(200.0, 700.0);

        double x2 = uniform_dist2(gen);
        double y2 = uniform_dist2(gen);
        geometry_msgs::Point msg2;
        msg2.x = x2;
        msg2.y = y2;

        double x3 = uniform_dist2(gen);
        double y3 = uniform_dist2(gen);
        geometry_msgs::Point msg3;
        msg3.x = x3;
        msg3.y = y3;

        ROS_INFO_STREAM("Foot Position: (" << msg2.x << ", " << msg2.y << ")");
        ROS_INFO_STREAM("Foot3 Position: (" << msg3.x << ", " << msg3.y << ")");

        publisher.publish(msg);
        publisher2.publish(msg2);
        publisher3.publish(msg3);

        rate.sleep();
    }

    return 0;
}
